#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    char c = 'm';
    char filename[256];
    char dispmode = 'a';
    char *buf = malloc(sizeof(char));
    off_t fsize;

    while (c == 'x' || c == 'o' || c == 'd' || c == 'm')
    {
        if (c == 'x')
        {
            break;
        }

        printf("\"o\" to enter a ﬁle name,\n\"d\" to select display mode\n\"x\" exit\n");
        c = fgetc(stdin);
        fgetc(stdin);

        if (c == 'd')
        {
            printf("\nEnter display mode 'a' for ascii or 'h' for hex\n");
            dispmode = fgetc(stdin);
            fgetc(stdin);
            if (dispmode == 'a')
            {
                printf("\n");
                for (int i = 0; i < fsize; i++)
                {
                    if ((buf[i] >= 0x0 && buf[i] <= 0x9) || (buf[i] >= 0xB && buf[i] <= 0x1F))
                    {
                        printf("%c", 0x20);
                    }
                    else if (buf[i] == 0x7F)
                    {
                        printf("%c", 0x3F);
                    }
                    else
                    {
                        printf("%c", buf[i]);
                    }
                }
                printf("\n\n");
            }
            if (dispmode == 'h')
            {
                printf("\n");
                printf("\n%08X   ", 0);
                for (int i = 0; i < fsize; i++)
                {
                    printf(" %02X", buf[i]);
                    if ((i + 1) % 16 == 0)
                    {
                        printf("\n%08X   ", i + 1);
                    }
                }
                printf("\n%08lx\n", fsize);
                printf("\n\n");
            }
        }
        else if (c == 'o')
        {
            printf("\nEnter file name\n");
            fgets(filename, 256, stdin);
            filename[strlen(filename) - 1] = '\0';
            //fgetc(stdin);
            int fd = open(filename, O_RDONLY);
            if (fd == -1)
            {
                printf("unable to open file %s\n", filename);
                return -1;
            }
            fsize = lseek(fd, 0, SEEK_END);
            lseek(fd, 0, SEEK_SET);
            buf = realloc(buf, sizeof(char) * (fsize + 1));
            read(fd, buf, fsize);
            close(fd);
            // printf("filename %s\n%s\n", filename, buf);
            printf("\n\"m\" to return to main menu\n\"x\" exit\n");
            c = fgetc(stdin);
            fgetc(stdin);
        }
    }
    free(buf);
    return 0;
}